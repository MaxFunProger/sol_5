from flask import Flask
from flask import render_template


app = Flask(__name__)


@app.route('/distribution')
def distribution():
    list_name = ['Ридли Скотт', 'Энди Уир', 'Марк Уотни',
                 'Венката Капур', 'Тедди Сандерс', 'Шон Бин']
    return render_template('list.html', list_name=list_name)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
